This program is made for showing a picture to 3d waterfall drawing image. Below is caution and explanation for this program

1. Before executing, please setting language to english.(영한키를 통해 영어로 설정해주세요.)
2. Before executing, please put main.png, unit.png, end.png and your own picture to bin/data
3. You can change picture by changing filename in ofApp.h 64 line.
4. Please put main.png, unit.png, end.png and your picture file in bin/data in your Openframeworks project.
5. When you want to end program, please enter 'q' key to free malloc

Thank you!
