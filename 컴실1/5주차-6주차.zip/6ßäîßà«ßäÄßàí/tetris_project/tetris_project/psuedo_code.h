//
//  psuedo_code.h
//  tetris_project
//
//  Created by Jeon Charn on 2021/04/09.
//

#ifndef psuedo_code_h
#define psuedo_code_h

#include <stdio.h>

#endif /* psuedo_code_h */
