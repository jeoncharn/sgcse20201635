//
//  psuedo_code.c
//  tetris_project
//
//  Created by Jeon Charn on 2021/04/09.
//

#include "psuedo_code.h"
#include "tetris.h"

int CheckToMove(char f[HEIGHT][WIDTH],int currentBlock,int blockRotate, int blockY, int blockX){
    for(int i=0; i<4; i++) // 이미 블록이 쌓여져 있는 경우
    {
        for(int j=0; j<4; j++)
        {
            if(block[currentBlock][blockRotate][i][j]==1 && f[blockY+i][blockX+j]==1)
            {
                return 0;
            }
        }
    }
    
    for(int i=0; i<4; i++) // y의 최대는 21 (0~21) / 22부터 x
    {
        for(int j=0; j<4; j++)
        {
            if(block[currentBlock][blockRotate][i][j]==1 && blockY+i>21)
            {
                return 0;
            }
        }
    }
    
    for(int i=0; i<4; i++) // x의 최대는 9(0~9), 최소는 0 segfault 를 발생시키지 않기 위해 먼저 test
    {
        for(int j=0; j<4; j++)
        {
            if(block[currentBlock][blockRotate][i][j]==1 && (blockX+i<0 || blockX+i>9))
            {
                return 0;
            }
        }
    }
    
    return 1;
}

void DrawChange(char f[HEIGHT][WIDTH],int command,int currentBlock,int blockRotate, int blockY, int blockX){
    switch(command){
    
    case KEY_UP:
            blockRotate = blockRotate - 1;
            if(blockRotate == -1)
            {
                blockRotate = 3;
            }
            DrawBlock(blockY,blockX,nextBlock[0],blockRotate,'*');
            
            blockRotate = (blockRotate + 1)%4;
            DrawBlock(blockY,blockX,nextBlock[0],blockRotate,' ');
            break;
            
    case KEY_DOWN:
            blockY--;
            DrawBlock(blockY,blockX,nextBlock[0],blockRotate,'*');
            blockY++;
            DrawBlock(blockY,blockX,nextBlock[0],blockRotate,' ');
            break;
            
    case KEY_RIGHT:
            blockX--;
            DrawBlock(blockY,blockX,nextBlock[0],blockRotate,'*');
            blockX++;
            DrawBlock(blockY,blockX,nextBlock[0],blockRotate,' ');
            break;
            
    case KEY_LEFT:
            blockX++;
            DrawBlock(blockY,blockX,nextBlock[0],blockRotate,'*');
            blockX--;
            DrawBlock(blockY,blockX,nextBlock[0],blockRotate,' ');
            break;
            
    default:
            break;
    }
    // user code

    //1. 이전 블록 정보를 찾는다. ProcessCommand의 switch문을 참조할 것
    //2. 이전 블록 정보를 지운다. DrawBlock함수 참조할 것.
    //3. 새로운 블록 정보를 그린다.
}

void BlockDown(int sig){
    // user code
    if(CheckToMove(field,nextBlock[0],blockRotate,blockY+1,blockX))
    {
        blockY++;
    }
    else
    {
        if(blockY==-1)
        {
            gameOver = 1;
        }
        else
        {
            AddBlockToField(field, nextBlock[0], blockRotate, blockY, blockX);
        }
    }
    //강의자료 p26-27의 플로우차트를 참고한다.
}

void AddBlockToField(char f[HEIGHT][WIDTH],int currentBlock,int blockRotate, int blockY, int blockX){
    
    for(int i=0; i<4; i++)
    {
        for(int j=0; j<4; j++)
        {
            if(block[currentBlock][blockRotate][i][j]==1)
            {
                f[blockY+i][blockX+j] = ' ';
            }
        }
    }
    //Block이 추가된 영역의 필드값을 바꾼다.
}

int DeleteLine(char f[HEIGHT][WIDTH]){
    int isfull[22] = {0};
    int count = 0;
    
    for(int i=0; i<22; i++)
    {
        for(int j=0; j<10; j++)
        {
            if(f[i][j]!=' ')
            {
                break;
            }
            else if(j==9 && f[i][j]==' ')
            {
                isfull[i] = 1;
            }
        }
    }
    
    for(int i=0; i<22; i++)
    {
        if(isfull[i]==1) // i가 0일때 예외처리 해주어야 할까?
        {
            count++;
            for(int k=i-1; k>=0; k--)
            {
                for(int j=0; j<10; j++)
                {
                    f[k+1][j] = f[k][j];
                }
            }
            for(int j=0; j<10; j++)
            {
                f[0][j]='*';
            }
        }
    }
    
    //1. 필드를 탐색하여, 꽉 찬 구간이 있는지 탐색한다.
    //2. 꽉 찬 구간이 있으면 해당 구간을 지운다. 즉, 해당 구간으로 필드값을 한칸씩 내린다.
    return count*count*100;
}
