#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "filesys/filesys.h"
#include "filesys/file.h"
#include "threads/synch.h"
#include "filesys/inode.h"


/* project 2 read/write 에서의 lock을 위해 */
struct lock syn_lock;

static void syscall_handler (struct intr_frame *);

void
syscall_init (void) 
{
    /* project 2, lock을 initialization */
    lock_init(&syn_lock);
    intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

// esp로 전달된 argument가 타당한 위치에 있는지 파악하는 함수이다.
void check_address(void* addr){
    if(!is_user_vaddr(addr)){
        exit(-1);
    }
}

/* 각 system call을 수행하는 함수이다. */

// pintos 자체를 종료하는 함수
void halt(void)
{
    shutdown_power_off();
}

// 현재 user program을 종료
void exit(int status)
{
    
    // int status를 thread sturuct에 할당한다.
    struct thread* cur = thread_current();
    //cur->status = THREAD_DYING;
    cur->exit_status = status;
    //process_exit();
    
    printf("%s: exit(%d)\n", cur->name, cur->exit_status);
    
    /* proeject 2 에서 구현한 fd에 대해 모든 file을 close 해주어야 한다. */
    
    for(int i=3; i<128; i++){
        if(cur->fd[i] != NULL){
            close(i);
        }
    }
    
    // exit 하는 process의 모든 child process을 wait 한다.
    struct thread* child = NULL;
    struct list_elem* e;
    for(e = list_begin(&(cur->child)); e != list_end(&(cur->child)); e = list_next(e)){
        struct thread* check = list_entry(e, struct thread, child_elem);
        process_wait(check->tid);
    }
    
    thread_exit();
    //printf("EXIT func executed.\n");
    
}

// cmd_line을 실행시키는 함수
tid_t exec(const char* cmd_line)
{
    return process_execute(cmd_line);
}

int wait(tid_t pid)
{
    // child thread ID check
    // exit status 받기
    return process_wait(pid);
}


/* project 2에서 구현한 system call function */
// file/file.h, file/filesys.h 에서 import한 함수들을 사용한다.

bool create(const char* file, unsigned initial_size)
{
    // create-null test
    if(file == NULL){
        exit(-1);
    }
    check_address(file);
    return filesys_create(file, initial_size);
}

bool remove(const char* file)
{
    if(file == NULL){
        exit(-1);
    }
    check_address(file);
    return filesys_remove(file);
}

int open(const char* file)
{
    // 모든 open file에 대해, 먼저 file_deny_write 을 수행할까?
    
    int return_value;
    // open-null test
    if(file == NULL){
        exit(-1);
    }
    // char*가 user_vaddr에 존재하는지 판단한다.
    check_address(file);
    
    //lock_acquire(&lock);

    struct thread* cur;
    struct file* open_file = filesys_open(file);
    if(open_file == NULL){
        return_value = -1;
    }
    else{
        cur = thread_current();
        // current_thread의 fd에서 NULL인 fd를 찾아 새로운 file* 을 할당한다.
        // 만약 I/O redirection, pipe의 구현이 필요하다면 3 -> 0 으로 변경
        for(int i=3; i<128; i++){
            // 비어 있는 file descripter 을 발견
            if(cur->fd[i] == NULL){
                cur->fd[i] = open_file;
                return_value = i;
                
                // 현재 thread와 open하는 file의 이름이 동일한 경우
                //if(strcmp(file, cur->name) == 0){
                //    file_deny_write(open_file);
                //}
                break;
            }
        }
    }
    //lock_release(&lock);
    
    return return_value;
}

int filesize(int fd)
{
    if(thread_current()->fd[fd] == NULL){
        exit(-1);
    }
    return file_length(thread_current()->fd[fd]);
}

int read(int fd, void* buffer, unsigned size)
{
    int return_value;
    check_address(buffer);
    lock_acquire(&syn_lock);
    // standard input이 아닌 경우
    if(fd > 2){
        if(thread_current()->fd[fd] == NULL){
            lock_release(&syn_lock);
            exit(-1);
        }
        //lock_acquire(&lock);
        return_value = file_read(thread_current()->fd[fd], buffer, size);
        //lock_release(&lock);
        //return return_value;
    }
    else if(fd == 0){
        //lock_acquire(&lock);
        for(int i=0; i<size; i++){
            if(input_getc() == '\0'){
                //lock_release(&lock);
                return_value = i;
                break;
            }
        }
    }
    else{
        return_value = -1;
    }
    lock_release(&syn_lock);
    
    return return_value;
}

int write(int fd, const void* buffer, unsigned size)
{
    int return_value;
    check_address(buffer);
    // standard output이 아닌 경우
    lock_acquire(&syn_lock);
    if(fd > 2){
        if(thread_current()->fd[fd] == NULL){
            lock_release(&syn_lock);
            exit(-1);
        }
        //lock_acquire(&lock);
        return_value = file_write(thread_current()->fd[fd], buffer, size);
        //lock_release(&lock);
        //return return_value;
    }
    else if(fd == 1){
        //lock_acquire(&lock);
        putbuf(buffer, size);
        return_value = size;
        //lock_release(&lock);
        //return size;
    }
    else{
        return_value = -1;
    }
    
    lock_release(&syn_lock);
    
    return return_value;
    
    
}

void seek(int fd, unsigned position)
{
    if(thread_current()->fd[fd] == NULL){
        exit(-1);
    }
    file_seek(thread_current()->fd[fd], position);
}

unsigned tell(int fd)
{
    if(thread_current()->fd[fd] == NULL){
        exit(-1);
    }
    return file_tell(thread_current()->fd[fd]);
}

void close(int fd)
{
    /*
    if(thread_current()->fd[fd] == NULL){
        exit(-1);
    }
     */
    struct thread* cur = thread_current();
    
    struct file* close_file = cur->fd[fd];
    thread_current()->fd[fd] = NULL;
    
    for(int i=3; i<128; i++){
        if(i != fd && cur->fd[i] == close_file)
            return;
    }
    // 만약 다른 file descriptor 에서 해당 file pointer을 point하지 않는 경우
    // file_close에서 file_allow_write가 실행된다.
    file_close(close_file);
}


/* project 1에서 추가적으로 구현한 system call function */
int fibonacci(int n){
    int n_1 = 0;
    int n_2 = 0;
    int result = 1;
    
    for(int i=1; i<n; i++){
        n_2 = n_1;
        n_1 = result;
        result = n_1 + n_2;
    }
    
    return result;
    
}

int max_of_four_int(int a, int b, int c, int d){
    
    int max = a;
    
    if(max<b){
        max = b;
    }
    if(max<c){
        max = c;
    }
    if(max<d){
        max = d;
    }
    
    return max;
}


/* project 5의 추가 구현해야 할 system call */
static bool
chdir (char *path)
{
    //return filesys_change_dir(path);
    return false;
}

static bool
mkdir (const char *dir)
{
    //return filesys_create_dir(dir);
    return false;
}

static bool
readdir (int fd, char *name)
{
    /*
    bool result = true;
    
    struct file *file = thread_current()->fd[fd];
    
    struct inode *inode = file_get_inode(file);
    if (inode == NULL)
    {
        return false;
    }
    
    if (!inode_is_dir(inode))
    {
        return false;
    }

    ...
     */
    
    return false;
}

static bool
isdir (int fd)
{
    //return inode_is_dir(file_get_inode(thread_current()->fd[fd]));
    return false;
}

static int
inumber (int fd)
{
    //inode_get_inumber(file_get_inode(thread_current()->fd[fd]));
    return -1;
}



static void
syscall_handler (struct intr_frame *f UNUSED) 
{
    //printf("current system call num : %d, current thread name : %s, tid : %d\n", *(uint32_t *)(f->esp), thread_current()->name, thread_current()->tid);
    //hex_dump(f->esp, f->esp, 100, 1);
    
    //thread_exit();
        
    switch (*(uint32_t *)(f->esp)) {
        case SYS_HALT:
            halt();
            break;
            
        case SYS_EXIT:
            check_address(f->esp + 4);
            exit(*(uint32_t *)(f->esp + 4));
            break;
            
        case SYS_EXEC:
            check_address(f->esp + 4);
            f->eax = exec(*(uint32_t *)(f->esp + 4));
            break;
            
        case SYS_WAIT:
            check_address(f->esp + 4);
            f->eax = wait(*(uint32_t *)(f->esp + 4));
            break;
            
            /*
        case SYS_READ:
            check_address(f->esp + 4);
            check_address(f->esp + 8);
            check_address(f->esp + 12);
            f->eax = read(*(uint32_t *)(f->esp + 4), *(uint32_t *)(f->esp + 8), *(uint32_t *)(f->esp + 12));
            break;
            
        case SYS_WRITE:
            check_address(f->esp + 4);
            check_address(f->esp + 8);
            check_address(f->esp + 12);
            f->eax = write(*(uint32_t *)(f->esp + 4), *(uint32_t *)(f->esp + 8), *(uint32_t *)(f->esp + 12));
            //printf("%d %p %d\n", *(uint32_t *)(f->esp + 4), *(uint32_t *)(f->esp + 8), *(uint32_t *)(f->esp + 12));
            break;
            */
        
        /* project 2 에서 구현해야 하는 system call */
            // file name 의 저장 위치 어디??
            
        case SYS_CREATE:
            check_address(f->esp + 4);
            check_address(f->esp + 8);
            f->eax = create(*(uint32_t *)(f->esp + 4), *(uint32_t *)(f->esp + 8));
            break;
        
        case SYS_REMOVE:
            check_address(f->esp + 4);
            f->eax = remove(*(uint32_t *)(f->esp + 4));
            break;
            
        case SYS_OPEN:
            check_address(f->esp + 4);
            f->eax = open(*(uint32_t *)(f->esp + 4));
            break;
        
        case SYS_FILESIZE:
            check_address(f->esp + 4);
            f->eax = filesize(*(uint32_t *)(f->esp + 4));
            break;
            
        case SYS_READ:
            check_address(f->esp + 4);
            check_address(f->esp + 8);
            check_address(f->esp + 12);
            f->eax = read(*(uint32_t *)(f->esp + 4), *(uint32_t *)(f->esp + 8), *(uint32_t *)(f->esp + 12));
            break;
        
        case SYS_WRITE:
            check_address(f->esp + 4);
            check_address(f->esp + 8);
            check_address(f->esp + 12);
            f->eax = write(*(uint32_t *)(f->esp + 4), *(uint32_t *)(f->esp + 8), *(uint32_t *)(f->esp + 12));
            break;
        
        case SYS_SEEK:
            check_address(f->esp + 4);
            check_address(f->esp + 8);
            seek(*(uint32_t *)(f->esp + 4), *(uint32_t *)(f->esp + 8));
            break;
            
        case SYS_TELL:
            check_address(f->esp + 4);
            f->eax = tell(*(uint32_t *)(f->esp + 4));
            break;
            
        case SYS_CLOSE:
            check_address(f->esp + 4);
            close(*(uint32_t *)(f->esp + 4));
            break;
            
        
        /* proeject 1에서 구현한 부분이다. */
            
        case SYS_FIBONACCI:
            check_address(f->esp + 4);
            f->eax = fibonacci(*(uint32_t *)(f->esp + 4));
            break;
        
        case SYS_MAX_OF_FOUR_INT:
            check_address(f->esp + 4);
            check_address(f->esp + 8);
            check_address(f->esp + 12);
            check_address(f->esp + 16);
            f->eax = max_of_four_int(*(uint32_t *)(f->esp + 4), *(uint32_t *)(f->esp + 8), *(uint32_t *)(f->esp + 12), *(uint32_t *)(f->esp + 16));
            break;
            
            
            
        /* project 5 에서 구현해야 할 syscall 함수이다. */
        case SYS_CHDIR:
            check_address(f->esp + 4);
            f->eax = chdir(*(uint32_t *)(f->esp + 4));
            break;
            
        case SYS_MKDIR:
            check_address(f->esp + 4);
            f->eax = mkdir(*(uint32_t *)(f->esp + 4));
            break;
            
        case SYS_READDIR:
            check_address(f->esp + 4);
            check_address(f->esp + 8);
            f->eax = readdir(*(uint32_t *)(f->esp + 4), *(uint32_t *)(f->esp + 8));
            break;
            
        case SYS_ISDIR:
            check_address(f->esp + 4);
            f->eax = isdir(*(uint32_t *)(f->esp + 4));
            break;
            
        case SYS_INUMBER:
            check_address(f->esp + 4);
            f->eax = inumber(*(uint32_t *)(f->esp + 4));
            break;
    }
}
