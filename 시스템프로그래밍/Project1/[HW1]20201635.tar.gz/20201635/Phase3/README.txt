[system programming project1 - Phase3]

You can make shell program by command make, delete by command make clean.
This shell is upgrade version of Phase3, which can do background jobs.
This shell is similar to linux shell, and can execute some commands below.


1. cd : this command change current directory
2. ls : this command lists what's in current directory
3. mkdir, rmdir : make, or remove directory
4. touch, cat, echo : create, read, print the contents of a file
5. ./ : can execute other program
6. | : make pipeline that connect two commands
7. & : execute command in background
8. jobs : show what's in background jobs
9. bg : run background suspended process in background
10. fg : run background process in foreground
11. kill : kill background process
12. exit : exit shell