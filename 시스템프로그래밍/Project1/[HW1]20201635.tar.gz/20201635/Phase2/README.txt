[system programming project1 - Phase2]

You can make shell program by command make, delete by command make clean.
This shell is upgrade version of Phase1, which can do pipelining jobs.
This shell is similar to linux shell, and can execute some commands below.


1. cd : this command change current directory
2. ls : this command lists what's in current directory
3. mkdir, rmdir : make, or remove directory
4. touch, cat, echo : create, read, print the contents of a file
5. ./ : can execute other program
6. | : make pipeline that connect two commands
7. exit : exit shell